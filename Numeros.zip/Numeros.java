package numeros;

	public class EliminarEspacios;
		public String EliminarEspaciosMetodo(String cadena){
			String newCadena="";
			String lada = "+52"
			
			newCadena = newCadena.substring(0, 6 ) + lada  
		for (int  i=0; i<cadena.length(); i++){
			if(cadena.charAt(i)!=' ' && cadena.charAt(i)!='\n'){
				newCadena=newCadena+cadena.charAt(i);
			}
		}

			return newCadena;
	}
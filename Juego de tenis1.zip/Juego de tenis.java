import java.util.Scanner;
public class tenis{
	public static void main (String [] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("Juegos ganados del jugador 1");
		int ja = sc.nextInt();

		Scanner st = new Scanner(System.in);
		System.out.print("Juegos ganados del jugador2");
		int jb = sc.nextInt();

		if (ja > 7){
			System.out.println("Invalido");
		}else if (jb >7){
			System.out.println("Invalido");
		}else{
			if (ja == 6 && jb <6){
			System.out.println("Gana el jugador 1");
			}else if (jb == 6 && ja < 6){
			System.out.println("Gana el jugador 2");
			}else {
				if (jb == 5 && ja == 5){
					System.out.println("Quedan 2 juegos");
				}else {
					if (jb == 6 && ja == 6) {
						System.out.println("Queda 1 juego");
				}else {

					if (jb < 5 && ja > 6) {
					System.out.println("Invalido");
					} else if (ja < 5 && jb > 6) {
					System.out.println("Invalido");
				}

				}
				}
			}
		}
	}
	}

 
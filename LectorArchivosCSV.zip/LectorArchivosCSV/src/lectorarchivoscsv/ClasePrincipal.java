/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lectorarchivoscsv;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author UrickG
 */
public class ClasePrincipal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Estadisticas estadisticas = new Estadisticas();
        Scanner sc = new Scanner(System.in);
        int op1,mes_ini,mes_f;
        do{
            System.out.print("Menu\n"
                + "1. Mostrar la diferencia de seguidores en Twitter entre dos meses\n"
                + "2. Mostrar la diferencia de visualizaciones en Youtube entre dos meses\n"
                + "3. Promedio de crecimiento en Facebook entre dos meses\n"
                + "4. Promedio de crecimiento en Twitter entre dos meses\n"
                + "5. Salir\n->");
            op1 = sc.nextInt();
            sc.nextLine();
            switch (op1) {
                case 1:
                    System.out.print("\nIngresa el mes inicial a comparar\n");
                    opcionMeses();
                    mes_ini = sc.nextInt();
                    sc.nextLine();
                    System.out.print("\nIngresa el mes final a comparar\n");
                    opcionMeses();
                    mes_f = sc.nextInt();
                    sc.nextLine();

                    System.out.println("La diferencia de seguidores es: " + estadisticas.diferenciaSeguidoresTwitter(mes_ini - 1, mes_f - 1));
                    break;
                case 2:
                    System.out.print("\nIngresa el mes inicial a comparar\n");
                    opcionMeses();
                    mes_ini = sc.nextInt();
                    sc.nextLine();
                    System.out.print("\nIngresa el mes final a comparar\n");
                    opcionMeses();
                    mes_f = sc.nextInt();
                    sc.nextLine();
                    System.out.println("La diferencia de visualizaciones es: " + estadisticas.diferenciaViewsYoutube(mes_ini - 1, mes_f - 1));
                    break;
                case 3:
                    System.out.print("\nIngresa el mes inicial a comparar\n");
                    opcionMeses();
                    mes_ini = sc.nextInt();
                    sc.nextLine();
                    System.out.print("\nIngresa el mes final a comparar\n");
                    opcionMeses();
                    mes_f = sc.nextInt();
                    sc.nextLine();

                    System.out.println("El porcentaje de crecimiento entre los meses es: " + estadisticas.porcentajeCrecimientoFacebook(mes_ini - 1, mes_f - 1) + "%");
                    break;
                case 4:
                    System.out.print("\nIngresa el mes inicial a comparar\n");
                    opcionMeses();
                    mes_ini = sc.nextInt();
                    sc.nextLine();
                    System.out.print("\nIngresa el mes final a comparar\n");
                    opcionMeses();
                    mes_f = sc.nextInt();
                    sc.nextLine();

                    System.out.println("El porcentaje de crecimiento entre los meses es: " + estadisticas.porcentajeCrecimientoTwitter(mes_ini - 1, mes_f - 1));
                    break;
            }
        } while (op1 != 5);

    }
    
    public static void opcionMeses(){
        System.out.print("\n1.Enero\n"
                            + "2.Febrero\n"
                            + "3.Marzo\n"
                            + "4.Abril\n"
                            + "5.Mayo\n"
                            + "6.Junio\n"
                            + "7.Julio\n"
                            + "8.Agosto\n"
                            + "9.Septiembre\n"
                            + "10.Octubre\n"
                            + "11.Noviembre\n"
                            + "12.Diciembre\n->");
    }
}

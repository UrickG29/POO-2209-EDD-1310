/*
 * Clase para leer archivo de extension CSV
 */
package lectorarchivoscsv;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author UrickG
 */

public class LeerArchivo {
    private BufferedReader reader;
    private String linea;
    private String [] token;
    private List<String> tokens;
    private int [] followersTwitter;
    private int [] viewYoutube;
    private int [] crecimientoFacebook;
    private int [] crecimientoTwitter;
    
    public LeerArchivo() {
        
    }
    
    /*El metodo  opedDocument lee el archivo de extension csv*/
    private BufferedReader openDocument() throws IOException{
        reader = null;
        try {
            File fichero = new File("presenciaredes.csv");
            reader = new BufferedReader(new FileReader(fichero.getAbsolutePath()));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LeerArchivo.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Lectura del archivo exitosa");
        return reader;
    }
    
    /*El metodo  tokenizar separa las palabras en tokens que estan originalmente separadas por comas*/
    private void tokenizar() throws IOException{
            int i, n_palabras = 0;
            reader = openDocument();
            tokens = new ArrayList<String>();
            while((linea = reader.readLine()) != null){
                linea = linea.replace("\"", "");//elimnando comillas dobles
                token = linea.split(",");//separa la cadena en tokens delimitados por comas
                n_palabras = token.length;
                i = 0;
                while(i < n_palabras){
                    tokens.add(token[i]);
                    //System.out.println(""+token[i]);
                    i++;
                }
            }
    }
    
    /*Este metodo obtiene los datos de seguidores de Twitter y los almacena en un vector*/
    public int[] getFollowersTwitter() throws IOException{
        int i = 0, j = 0, n_palabras = 0;
        followersTwitter = new int [12];
        tokenizar();//arreglo de palabras extraidas
        n_palabras = tokens.size(); //cantidad de palabras leidas
        
        while(i < n_palabras){
            if(tokens.get(i).equals("TWITTER") && tokens.get(i+1).equals("SEGUIDORES (FOLLOWERS)") ){
                i=i+3;
                while(j < 12){
                    followersTwitter[j] = Integer.parseInt(tokens.get(i));
                    j++;
                    i++;
                }
                break;
            }
            i++;
        }
        
        return followersTwitter;
    }
    
    /*Este metodo obtiene los datos de visualizaciones en Youtube*/
    public int[] getViewYoutube() throws IOException{
        int i = 0, j = 0, n_palabras = 0;
        viewYoutube = new int [12];
        tokenizar();//arreglo de palabras extraidas
        n_palabras = tokens.size(); //cantidad de palabras leidas
        
        while(i < n_palabras){
            if(tokens.get(i).equals("YOUTUBE") && tokens.get(i+1).equals("VISUALIZACIONES") ){
                i=i+3;
                while(j < 12){
                    viewYoutube[j] = Integer.parseInt(tokens.get(i));
                    j++;
                    i++;
                }
                break;
            }
            i++;
        }
        
        return viewYoutube;
    }
    
    /*Este metodo obtiene los datos de crecimiento en Facebook*/
    public int[] getCrecimientoFacebook() throws IOException{
        int i = 0, j = 0, n_palabras = 0;
        crecimientoFacebook = new int [12];
        tokenizar();//arreglo de palabras extraidas
        n_palabras = tokens.size(); //cantidad de palabras leidas
        
        while(i < n_palabras){
            if(tokens.get(i).equals("FACEBOOK") && tokens.get(i+1).equals("CRECIMIENTO (seguidores)") ){
                i=i+3;
                while(j < 12){
                    crecimientoFacebook[j] = Integer.parseInt(tokens.get(i));
                    j++;
                    i++;
                }
                break;
            }
            i++;
        }
        return crecimientoFacebook;
    }    
    
    /*Este metodo obtiene los datos de crecimiento en Twitter*/
    public int[] getCrecimientoTwitter() throws IOException{
        int i = 0, j = 0, n_palabras = 0;
        crecimientoTwitter = new int [12];
        tokenizar();//arreglo de palabras extraidas
        n_palabras = tokens.size(); //cantidad de palabras leidas
        
        while(i < n_palabras){
            if(tokens.get(i).equals("TWITTER") && tokens.get(i+1).equals("CRECIMIENTO DE FOLLOWERS") ){
                i=i+3;
                while(j < 12){
                    crecimientoTwitter[j] = Integer.parseInt(tokens.get(i));
                    j++;
                    i++;
                }
                break;
            }
            i++;
        }
        
        return crecimientoTwitter;
    }
}

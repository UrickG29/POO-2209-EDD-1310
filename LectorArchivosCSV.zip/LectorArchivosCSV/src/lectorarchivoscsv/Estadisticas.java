/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lectorarchivoscsv;

import java.io.IOException;

/**
 *
 * @author UrickG
 */
public class Estadisticas {
    private LeerArchivo datos;

    public Estadisticas() {
        datos = new LeerArchivo();
    }
    
    /*Este metodo retorna la diferencia de seguidores de Twitter entre dos meses*/
    public int diferenciaSeguidoresTwitter(int mes_inicio, int mes_fin) throws IOException{
        int [] datos_mes = datos.getFollowersTwitter();
        if(mes_inicio > 11 || mes_fin > 11 || mes_inicio < 0 || mes_fin < 0){
            return -1;
        }else{
            return Math.abs(datos_mes[mes_inicio] - datos_mes[mes_fin]);
        }
    }
    
    /*Este metodo retorna la diferencia de visualizaciones en Youtube entre dos meses*/
    public int diferenciaViewsYoutube(int mes_inicio, int mes_fin) throws IOException{
        int [] datos_mes = datos.getViewYoutube();
        if(mes_inicio > 11 || mes_fin > 11 || mes_inicio < 0 || mes_fin < 0){
            return -1;
        }else{
            return Math.abs(datos_mes[mes_inicio] - datos_mes[mes_fin]);
        }
    }
    
    /*Este metodo calcula el porcentaje de crecimiento de seguidotes en Facebook*/
    public double porcentajeCrecimientoFacebook(int mes_inicio, int mes_fin) throws IOException{
        int [] datos_mes = datos.getCrecimientoFacebook();
        int diferencia;
        
        if(mes_inicio > 11 || mes_fin > 11 || mes_inicio < 0 || mes_fin < 0){
            return -1;
        }else{
            diferencia = Math.abs(datos_mes[mes_inicio] - datos_mes[mes_fin]);
            return (diferencia*100)/datos_mes[mes_fin];
        }
    }
    
    /*Este metodo calcula el porcentaje de crecimiento de seguidotes en Twitter*/
        public int porcentajeCrecimientoTwitter(int mes_inicio, int mes_fin) throws IOException{
        int [] datos_mes = datos.getCrecimientoFacebook();
        int diferencia;
        
        if(mes_inicio > 11 || mes_fin > 11 || mes_inicio < 0 || mes_fin < 0){
            return -1;
        }else{
            diferencia = Math.abs(datos_mes[mes_inicio] - datos_mes[mes_fin]);
            return (diferencia*100)/datos_mes[mes_fin];
        }
    }
}
